# OXID 6 - Modul with Composer.

[![Donate](https://img.shields.io/badge/Donate-PayPal-green.svg)](https://www.paypal.me/PTMarkus)

> Dies ist ein Beispiel Modul für das Tutorial unter https://www.programmier-tipps.de/2019/07/07/oxid-6-modul-erstellen-mit-namespaces-und-composer/

## OXID Version

| OXID eShop        | PHP       |
| ----------------- | ----------|
| 6.x               | 7.1       |

## Installation

Via Composer 

    composer require protipps/technical_details