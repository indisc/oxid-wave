<?php
/**
 * Modul: technical_details
 * Web: https://www.programmier-tipps.de
 * Mail: kontakt@programmier-tipps.de
 * (c) 2019 by programmier-tipps.de
 */

$sLangName  = "Deutsch";

$aLang = [

    'charset'                                           => 'UTF-8',

    'PROTIPPS_TECHNICAL_DETAILS'                        => 'Technische Details',
    'PROTIPPS_TECHNICAL_DETAILS_MATERIAL'               => 'Material',
    'PROTIPPS_TECHNICAL_DETAILS_POWER'                  => 'Stromaufnahme',
    'PROTIPPS_TECHNICAL_DETAILS_POWER_SUPPLY'           => 'Spannungsversorgung',
    'PROTIPPS_TECHNICAL_DETAILS_BATTERY_OPERATION'      => 'Batteriebetrieb',
    'PROTIPPS_TECHNICAL_DETAILS_BATTERY_QUANTITY'       => 'Batteriemenge',
    'PROTIPPS_TECHNICAL_DETAILS_BATTERY_TYPE'           => 'Batterietyp',

];