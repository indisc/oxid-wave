<?php
/**
 * Modul: technical_details
 * Web: https://www.programmier-tipps.de
 * Mail: kontakt@programmier-tipps.de
 * (c) 2019 by programmier-tipps.de
 */

$sLangName  = "English";

$aLang = [

    'charset'                                           => 'UTF-8',

    'PROTIPPS_TECHNICAL_DETAILS'                        => 'Technical details',
    'PROTIPPS_TECHNICAL_DETAILS_MATERIAL'               => 'Material',
    'PROTIPPS_TECHNICAL_DETAILS_POWER'                  => 'Power',
    'PROTIPPS_TECHNICAL_DETAILS_POWER_SUPPLY'           => 'Power supply',
    'PROTIPPS_TECHNICAL_DETAILS_BATTERY_OPERATION'      => 'Battery operation',
    'PROTIPPS_TECHNICAL_DETAILS_BATTERY_QUANTITY'       => 'Battery quantity',
    'PROTIPPS_TECHNICAL_DETAILS_BATTERY_TYPE'           => 'Battery type',

];